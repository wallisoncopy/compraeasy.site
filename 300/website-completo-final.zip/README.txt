INSTRUÇÕES PARA USAR SEU SITE DE MOLDES DE ROUPAS
====================================================

CONTEÚDO DO ARQUIVO:
- index.html - Página principal do site
- style.css - Estilos e design responsivo
- script.js - Funcionalidades (timer, FAQ, animações)
- pasta images/ - Todas as imagens dos moldes e pacotes

COMO USAR:
1. Extraia todos os arquivos em uma pasta
2. Mantenha a estrutura de pastas (não mova as imagens)
3. Abra o arquivo index.html em qualquer navegador
4. Para hospedar online, envie TODOS os arquivos para seu servidor

IMPORTANTE:
- NÃO altere os nomes das imagens
- NÃO mova a pasta "images"
- Sempre mantenha todos os arquivos juntos

LINKS DE CHECKOUT:
- Atualmente os botões de R$17 e R$27 direcionam para: https://compraeasy.site/
- Para alterar, edite o arquivo index.html e procure por "compraeasy.site"

PERSONALIZAÇÃO:
- Para trocar o GIF: substitua o conteúdo da seção "gif-demo-section"
- Para alterar cores: edite o arquivo style.css
- Para mudar textos: edite o arquivo index.html

Seu site está 100% funcional e responsivo!